	window.addEventListener('load', detalle_persona, false);

function detalle_persona(){
	onclick="pickOpen('prod', 'id_prod',
		'<?php echo BASE_URL."personal/update/". $persona['id_persona'] ?>', 
		90, 90, 70, 50);show('prod',500);show('id_aceptar',500);hide('id_buscar',500);"
}