
function mostrar(){
    document.getElementById('uno').style.display='block';
}
function ocultar(){
    document.getElementById('uno').style.display='none';
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//-----------------------VENTANA MODAL PARA EL DETALLE DE LA SOLICITUD-------
function send_detalle_persona(id_persona) {
        //alert('../../catic/personal/prueba');
    send_ajax('POST', '../../catic/personal/detallePersona', 'responde_detalle_persona', 'id_persona=' + id_persona, null,true);
}
function responde_detalle_persona(response) {
    //alert(response[0]['nombre']+response[0]['apellido']);
     var tbl = document.getElementById('tabla_detalle_persona');
    
    if (response == '') {
        if (borrar_tabla('tabla_detalle_persona')) {
            var tr = document.createElement('tr');
            tr.style.align = 'center';
            var cell = document.createElement('td');
            cell.align = 'center';
            cell.width = 'auto';
            cell.setAttribute('colspan', '11');
            var node = document.createTextNode('No se a la persona a consultar');
            cell.appendChild(node);
            tr.appendChild(cell);
            tbl.tBodies[0].appendChild(tr);

        }
    } else {

        if (borrar_tabla('tabla_detalle_persona')) {
            var lista = response;
            var len= lista.length;
            var campos;
            for (var i = 0; i < len; i++) {
                campos = lista[i];
                tbl.tBodies[0].appendChild(addRowDatosSeleccion2(campos));
                paintTRsClearDark('tabla_detalle_persona');
            }

        }
    } 

    tbl.setAttribute("style","display:block");
    vista_preliminar();
}



function addRowDatosSeleccion2(row) {
   // alert(Object.keys(row));
    var tam = new Array();
        tam[0]='79px';
        tam[1]='135px';
        tam[2]='138px';
        tam[3]='136px';
        tam[4]='136px';
        tam[5]='52px';
        tam[6]='101';
        tam[7]='110px';
        tam[8]='205px'
        tam[9]='180px'
    
    var tr = document.createElement('tr');
   
    tr.style.align = 'center';
    var cell = new Array();
    var node = new Array();
    tr.setAttribute('id',row[0]);
    delAttrWithNumIndex(row);

    var j=0;

        var x;
        for (x in row) {
  
        cell[j] = document.createElement('td');
        cell[j].align = 'center';
        cell[j].setAttribute('style','min-width: '+tam[j]+'; max-width: '+tam[j]/*+'color: BA3131;'+' color: BA3131'*/);        

            node[j] = document.createTextNode(row[x]);
            cell[j].appendChild(node[j]);
            tr.appendChild(cell[j]);  
            j++;

    }

    return tr;
}


