function crearDivHijos(divName,NumDiv){
	var i = 0;
	hide(divName,0);
	switch(divName){
		case 'infoHijos':
		show('infoHijos', 1500);
		  break;
		case 'div_hijos':
		hide('div_hijos_2');
		show('div_hijos', 1500);
		  break;
		case 'div_hijos_2':
		hide('div_hijos');
		show('div_hijos_2', 1500);
			  
	}
}

function cerrarDivHijos(divName,NumDiv){
	var i = 0;
	hide(divName,0);
	switch(divName){
		case 'infoHijos':
		hide('infoHijos', 1500);
		  break;  
	}
}

