
// 	window.addEventListener('load', alert, false);

	
// function alert() {
// alert("Aviso: Desde esta misma ventana usted podra editar los datos de la persona.");
// }

